import '../style/visual.less';

import * as echarts from 'echarts'

export default class Visual extends WynVisual {
  private container: HTMLDivElement;
  private chart: any;
  private properties: any;
  private items: any;

  constructor(dom: HTMLDivElement, host: VisualNS.VisualHost, options: VisualNS.IVisualUpdateOptions) {
    super(dom, host, options)
    this.container = dom;
    this.chart = echarts.init(dom)
    this.items = [];
    this.properties = {
      barWidth: 14,
      fontSize: 14,
      textColor: '#ffffff',
      barBackgroundColor: '#444a58',
      barStartColor: '#57eabf',
      barEndcolor: '#2563f9',
    };
    this.render()
  }

  public update(options: VisualNS.IVisualUpdateOptions) {
    console.log(options, '=====update options');
    this.render()
  }
  
  public render () {
    
    const option = {
      tooltip : {
          trigger:'axis',
          axisPointer:{
              type:'shadow'
          },
          formatter: function (params) {
              var tar;
              if (params[1].value != '-') {
                  if (params[2] != '-') {
                      tar = params[1];
                      tar.value = params[1].value+params[2].value;
                  }else{
                      tar = params[1];
                  }
              }
              else {

                  tar = params[0];
              }
              return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
          }
      },
      grid:{
          backgroundColor:['#ECFFFB','#B4F1F1']
      },
      xAxis:{
          //type:'category',
          data:['Before', 'Factor A', 'Factor B', 'Factor C', 'Factor D', 'Factor E', 'Factor F', 'Factor G', 'After'],
          splitLine:{
              show:false
          }
      },
      yAxis:{
          type:'value',
          splitArea: {
             show: true
          }
      },
      legend: {
          left: 'left',
          data: ['start&end','up','down']
      },
      series : [
          {//起始结束柱形[0]
              name:'start&end',
              type:'bar',
              stack:'total',
              barCategoryGap:'0',
              itemStyle: {
                  normal: {
                      barBorderColor: '#303841',
                      color: '#303841'
                  },
                  emphasis: {
                      barBorderColor: '#303841',
                      color: '#303841'
                  }
              },
              data:[325, '-', '-', '-', '-', '-', '-', '-', 1030]

          },
          {//辅助柱形[1]
              name:'Left',
              type:'bar',
              stack:'total',
              barCategoryGap:'0',
              itemStyle: {
                  normal: {
                      barBorderColor: 'rgba(0,0,0,0)',
                      color: 'rgba(255,255,255,255)'
                  },
                  emphasis: {
                      barBorderColor: 'rgba(0,0,0,0)',
                      color: 'rgba(255,255,255,255)'
                  }
              },
              data:['-', 293, 188, 188, 226, 312, 409, 641, '-']
          },
          {//上升的红色柱形[2]
              name:'up',
              type:'bar',
              stack:'total',
              barCategoryGap:'0',
              label: {
                  normal: {
                      show: true,
                      position: 'top'
                  }
              },
              itemStyle: {
                  normal: {
                      barBorderColor: '#FF5722',
                      color: '#FF5722'
                  },
                  emphasis: {
                      barBorderColor: '#FF5722',
                      color: '#FF5722'
                  }
              },
              data:['-', '-', '-', 38, 86, 97, 232, 389, '-']
          },
          {//下降的绿色柱形[3]
              name:'down',
              type:'bar',
              stack:'total',
              barCategoryGap:'0',
              label: {
                  normal: {
                      show: true,
                      position: 'bottom'
                  }
              },
              itemStyle: {
                  normal: {
                      barBorderColor: '#00ADB5',
                      color: '#00ADB5'
                  },
                  emphasis: {
                      barBorderColor: '#00ADB5',
                      color: '#00ADB5'
                  }
              },
              data:['-', 32, 105, '-', '-', '-', '-', '-', '-']
          }
      ],
  };
    
  this.chart.setOption(option)

  }
  public onDestroy() {

  }

  public onResize() {
    this.chart.resize();
    this.render();
  }

  public getInspectorHiddenState(options: VisualNS.IVisualUpdateOptions): string[] {
    return null;
  }

  public getActionBarHiddenState(options: VisualNS.IVisualUpdateOptions): string[] {
    return null;
  }
}